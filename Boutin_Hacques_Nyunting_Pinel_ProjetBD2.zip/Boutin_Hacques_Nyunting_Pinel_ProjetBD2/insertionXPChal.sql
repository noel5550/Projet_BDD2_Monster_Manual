-- Insertions dans la table XPChallenge

INSERT INTO XPChallenge VALUES (seqXP.nextVal, 0);
-- On saute les challenge entre 0 et 1 car on est sur des entiers
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 200);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 450);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 700);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 1100);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 1800);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 2300);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 2900);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 3900);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 5000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 5900);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 7200);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 8400);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 10000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 11500);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 13000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 15000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 18000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 20000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 22000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 25000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 33000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 41000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 50000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 62000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 75000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 90000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 105000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 120000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 135000);
INSERT INTO XPChallenge VALUES (seqXP.nextVal, 155000);
commit;
