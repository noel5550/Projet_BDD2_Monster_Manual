--Insertions dans la table Taille
INSERT INTO Taille VALUES ('Tiny', 4);
INSERT INTO Taille VALUES ('Small', 6);
INSERT INTO Taille VALUES ('Medium', 8);
INSERT INTO Taille VALUES ('Large', 10);
INSERT INTO Taille VALUES ('Huge', 12);
INSERT INTO Taille VALUES ('Gargantuan', 20);
commit;
