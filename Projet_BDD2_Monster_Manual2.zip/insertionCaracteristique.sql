-- Insertions dans la table Caracteristique

INSERT INTO Caracteristique(idMob, nom, taille, race, morale, ethique, aC, multiplePV, constantePV, cR, attSTR, attDEX, attCON, attINT, attWIS, attCHA, vu) VALUES (seqIdMob.nextval, 'JCVD', 'Medium', 'Humain', 'neutral', 'good', 20, 100, 100, 20, 25, 25, 25, 25, 25, 25, 1);
commit;
