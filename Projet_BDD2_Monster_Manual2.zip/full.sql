@Crea_Table_Taille.sql
@Crea_Table_Race.sql
@Crea_Table_XPChal.sql
@Crea_Table_Carac.sql
@Crea_Table_Lang.sql
@Crea_Table_Comp.sql
@Crea_Table_Depla.sql

@insertionTaille.sql
@insertionRace.sql
@insertionXPChal.sql

@Crea_View_Glob.sql
@Crea_View_Soci.sql
@Crea_View_Comb.sql

@Crea_Role.sql
