-- Insertions dans la table Race

INSERT INTO Race VALUES ('Humain', 'plaine', 'Humain');
INSERT INTO Race VALUES ('Elfe', 'foret','Elfe');
INSERT INTO Race VALUES ('Nain', 'montagne', 'Nain');
INSERT INTO Race VALUES ('Hobbit', 'comte', 'Hobbit');
commit;
